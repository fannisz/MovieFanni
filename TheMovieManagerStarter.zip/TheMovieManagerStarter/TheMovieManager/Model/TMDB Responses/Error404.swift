//
//  Error404.swift
//  TheMovieManager
//
//  Created by Fanni Szente on 09/06/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct Error404: Codable {
    let statusMessage: String
    let statusCode: Int
    
    enum CodingKeys: String, CodingKey {
        case statusMessage = "status_message"
        case statusCode = "status_code"
    }
}
