//
//  Error401.swift
//  TheMovieManager
//
//  Created by Fanni Szente on 09/06/2020.
//  Copyright © 2020 Udacity. All rights reserved.
//

import Foundation

struct Error401: Codable {
    let statusMessage: String
    let success: Bool
    let statusCode: Int
    
    enum CodingKeys: String, CodingKey {
        case statusMessage = "status_message"
        case success
        case statusCode = "status_code"
    }
}
